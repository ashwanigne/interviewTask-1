# interviewTask-1
Create a Page that reads data from JSON File.
